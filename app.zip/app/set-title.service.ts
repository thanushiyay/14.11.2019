import { Injectable } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Title } from '@angular/platform-browser';
import { MainServiceService } from './main-service.service';
import { MatDialog } from '@angular/material';
import { MainDialogComponent } from './main-dialog/main-dialog.component';
import { YoutubeDialogComponent } from './youtube-dialog/youtube-dialog.component';

@Injectable({
  providedIn: 'root'
})
export class SetTitleService {
 
  present_title:any[];
  urlString:any[];
  constructor(private router:Router,private activatedRoute:ActivatedRoute,private _titleService:Title,
    private _mainService:MainServiceService,private dialog:MatDialog) { }
  checkPageTitle() {
     this.urlString=this.router.url.split('/');
     console.log(this.router.url);
     let urlLength=this.urlString.length;
     if(this.urlString[urlLength-1]=== 'home')
     {
           this._titleService.setTitle("Plan Trips With Videos - SeeVoov");
           
     }
     else if(this.urlString[urlLength-1]==='choose-travel-kind')
     {
           this._titleService.setTitle("Plan your trip to " +this._mainService.getOption() + " - SeeVoov");
         //   this.dialog.open(MainDialogComponent);
     }
     else if(this.urlString[urlLength-1]==='where-to-go')
     {
        this._titleService.setTitle(this._mainService.getOption() + " Attractions - SeeVoov");
      //   this.dialog.open(YoutubeDialogComponent);
     }
     else if(this.urlString[urlLength-1]==='trip-information')
     {
        this._titleService.setTitle("Trip Information - SeeVoov");
      //   this.dialog
     }
  }
}
