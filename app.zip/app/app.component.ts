import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Title } from '@angular/platform-browser';
import { SetTitleService } from './set-title.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent  implements OnInit{
  // router: any;
  // opened=false;
  constructor(private router:Router,private _setTitleService:SetTitleService){}
         ngOnInit()
         {
             setTimeout(()=>
             {
              this.router.navigate(['home']);
              setTimeout(()=>
              {
                this._setTitleService.checkPageTitle();
              },3);
             },1);
            
             

         }
}
