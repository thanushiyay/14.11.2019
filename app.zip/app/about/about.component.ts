import { Component, OnInit } from '@angular/core';
//import { IgxCalendarComponent } from 'igniteui-angular';
@Component({
  selector: 'app-about',
  templateUrl: './about.component.html',
  styleUrls: ['./about.component.css']
})
export class AboutComponent implements OnInit {
  // @ViewChild('calendar', { read: IgxCalendarComponent }) public calendar: IgxCalendarComponent;
  constructor() { }
  //@ViewChild('calendar', { read: IgxCalendarComponent }) public calendar: IgxCalendarComponent;
  ngOnInit() {
  }

}
