import { Component, Renderer2,OnInit } from '@angular/core';
import {MatDialog, MatDialogRef} from '@angular/material';
import { MainDialogComponent } from '../main-dialog/main-dialog.component';
import { MainServiceService } from '../main-service.service';
// import { interval } from 'rxjs';
import {DomSanitizer} from  '@angular/platform-browser';
import { validateBasis } from '@angular/flex-layout';
// import { OwlOptions } from 'ngx-owl-carousel-o';
import { OwlOptions } from 'ngx-owl-carousel-o';
import { PopUpDialogComponent } from '../pop-up-dialog/pop-up-dialog.component';
import {ActivatedRoute,Router, Route} from '@angular/router';
import { TripDialogComponent } from '../trip-dialog/trip-dialog.component';
import { IgxCardThumbnailDirective } from 'igniteui-angular';
import {Title} from '@angular/platform-browser';
import { SetTitleService } from '../set-title.service';
@Component({
  selector: 'app-youtube-dialog',
  templateUrl: './youtube-dialog.component.html',
  styleUrls: ['./youtube-dialog.component.css']
})
export class YoutubeDialogComponent implements OnInit {
  place: string;
  seeing_place: string;
  ticked=false;
  // check_circle:string;
  check_circle="fa fa-check-circle";
  public places_title=['With Kids','Museums and Culture','Sight Seeing','Gastronomy','Night Life and Shopping'];
  public places_details=[
          {'title':'With kids',
            'details':
             [
               {
                 'name':'wth-kids1','image':"../assets/images/details_image/dom.jpg",'content':'This is an amazing place',
                 'embed':'https://www.youtube.com/embed/kpK03Ix1qEo','rating':4,'est_hrs':2
               },
               {
                 'name':'with-kids2','image':"../assets/images/details_image/dom.jpg",'content':'A beautiful place',
                 'embed':"https://www.youtube.com/embed/ogyEz71cnuA",'rating':4,'est_hrs':2
               }
             ]
            },
            {'title':'Museums and Culture',
            'details':
             [
               {
                 'name':'Museums and Culture1','image':"../assets/images/details_image/dom.jpg",'content':'Museums Content',
                 'embed':"https://www.youtube.com/embed/6wD4V0rvlDI",'rating':4,'est_hrs':2
               },
               {
                 'name':'Museums and Culture2','image':"../assets/images/details_image/dom.jpg",'content':'Museums Contetn2',
                 'embed':"https://www.youtube.com/embed/6wD4V0rvlDI",'rating':4,'est_hrs':2
               }
             ]
            },
            {'title':'Sight Seeing',
            'details':
             [
               {
                 'name':'Sight Seeing1','image':"../assets/images/details_image/dom.jpg",'content':'See the sight SeeingSee the second sight seeing See the second sight seeing SeeingSee the second sight seeing Seeing',
                 'embed':"https://www.youtube.com/embed/6wD4V0rvlDI",'rating':4,'est_hrs':2
               },
               {
                 'name':'Sight Seeing2','image':"../assets/images/bg_image.jpg",'content':'See the second sight seeing See the second sight seeing SeeingSee the second sight seeing Seeing',
                 'embed':"https://www.youtube.com/embed/6wD4V0rvlDI",'rating':4,'est_hrs':3
               },
               {
                'name':'Sight Seeing3','image':"../assets/images/details_image/dom.jpg",'content':'See the sight SeeingSee the second sight seeing See the second sight seeing SeeingSee the second sight seeing Seeing',
                'embed':"https://www.youtube.com/embed/6wD4V0rvlDI",'rating':4,'est_hrs':2
              },
              {
                'name':'Sight Seeing4','image':"../assets/images/details_image/dom.jpg",'content':'See the sight SeeingSee the second sight seeing See the second sight seeing SeeingSee the second sight seeing Seeing',
                'embed':"https://www.youtube.com/embed/6wD4V0rvlDI",'rating':4,'est_hrs':4
              },
              {
                'name':'Sight Seeing5','image':"../assets/images/details_image/dom.jpg",'content':'See the sight SeeingSee the second sight seeing See the second sight seeing SeeingSee the second sight seeing Seeing',
                'embed':"https://www.youtube.com/embed/6wD4V0rvlDI",'rating':4,'est_hrs':3
              },
              {
                'name':'Sight Seeing6','image':"../assets/images/details_image/dom.jpg",'content':'See the sight SeeingSee the second sight seeing See the second sight seeing SeeingSee the second sight seeing Seeing',
                'embed':"https://www.youtube.com/embed/6wD4V0rvlDI",'rating':4,'est_hrs':5
              },
             ]
            },
            {'title':'Gastronomy',
            'details':
             [
               {
                 'name':'Gastronomy1','image':"../assets/images/details_image/dom.jpg",'content':'See the sight Seeing',
                 'embed':"https://www.youtube.com/embed/6wD4V0rvlDI",'rating':4,'est_hrs':2
               },
               {
                 'name':'Gastronomy2','image':"../assets/images/details_image/dom.jpg",'content':'See the sight Seeing',
                 'embed':"https://www.youtube.com/embed/6wD4V0rvlDI",'rating':4,'est_hrs':2
               }
             ]
            },
            {'title':'Night Life and Shopping',
            'details':
             [
               {
                 'name':'Night Life and Shopping1','image':"../assets/images/details_image/dom.jpg",'content':'See the sight Seeing',
                 'embed':"https://www.youtube.com/embed/6wD4V0rvlDI",'rating':4,'est_hrs':2
               },
               {
                 'name':'Night Life and Shopping2','image':"../assets/images/details_image/dom.jpg",'content':'See the sight Seeing',
                 'embed':"https://www.youtube.com/embed/6wD4V0rvlDI",'rating':4,'est_hrs':2
               }
             ]
            },
  ];
  
  customOptions: OwlOptions = {
    loop: true,
    mouseDrag: false,
    touchDrag: false,
    pullDrag: false,
    dots: false,
    navSpeed: 700,
    navText: ['<h5 class="fa fa-angle-left"></h5>', '<h5 class="fa fa-angle-right"></h5>'],
    responsive: {
      0: {
        items: 1
      },
      50: {
        items: 2
      },
       100: {
         items: 3
       },
       150: {
         items: 4
       },
      200: {
        items: 5
       },
       250: {
         items: 6
       }
      
    
    },
    nav: true
  }

  addArray:string[]=[];
  est_hrs:number;
  det_name:string
  activeClass=false;
  youtube_value: any;
  your_value: string;
  _your_value: string;
  popUpDialog: string;
  hrs: number;
  title:string;
  constructor(public dialogRef:MatDialogRef<YoutubeDialogComponent>,public dialog:MatDialog,
    public _mainService:MainServiceService,private sanitizer:DomSanitizer,
    private router:Router,private route:ActivatedRoute,private _titleService:Title,
    private _setTitleService:SetTitleService) { }
  
  ngOnInit() {
    this.place=this._mainService.getOption();
    this.seeing_place=this._mainService.getSeeing_place();
    this.youtube_value=this.sanitizer.bypassSecurityTrustResourceUrl('https://www.youtube.com/embed/6wD4V0rvlDI');
    this.est_hrs=0;
    this._setTitleService.checkPageTitle();
  }
  dialogBack()
  {
     this.dialogRef.close();
     this.dialog.open(MainDialogComponent,{disableClose:true});
     this.router.navigate(['plan-trip',this._mainService.getOption(),'choose-travel-kind'],{relativeTo:this.route});
     setTimeout(()=>
     {
              this._setTitleService.checkPageTitle();
     },5);
     
    }
  dialogClose()
  {
    this.dialogRef.close();
    this.dialog.afterAllClosed.subscribe(result=>
      {
         this.router.navigate(['../'],{relativeTo:this.route});    
         setTimeout(()=>
         {
           // console.log("This is home page:" +this.router.url);
                  this._setTitleService.checkPageTitle();
         },5);
      });
  
      
  }
  playPlayer(value:string)
  {
     console.log(value);
     this.youtube_value=this.sanitizer.bypassSecurityTrustResourceUrl(value);
  }
   activeCall()
   {
       this.activeClass=true;
   }
   isTicked(det_name:string)
   {

    for(let x of this.places_details)
    {
       for(let y of x.details)
       {
         if(y.name==det_name)
         {
            this.hrs=y.est_hrs;
            
         }
       }
    }
        if(this.addArray.includes(det_name))
        {
          const index: number = this.addArray.indexOf(det_name);
          this.addArray.splice(index,1);
          console.log(this.addArray);
          console.log("removed");
          this.est_hrs=this.est_hrs-this.hrs;
        }
        else
        {
          this.addArray.push(det_name);
            this.est_hrs=this.est_hrs+this.hrs;
          console.log("added");
         
        }
       
   }
   checkTicked(det_name:string)
   {
         if(this.addArray.includes(det_name))
         {
            this.ticked=true;
            // console.log("hiiii");
            return true;
         }
         else
         {
           return false;
         }
        //  console.log("chintuu");
         
   }
   isArrayHaving()
   {
      // const  greyColor:HTMLElement=document.getElementById('hr_style');
      if(this.addArray.length>0)
      {
        return true;
      }
      else
      {
        return false;
      }
   }
   pTagShow=false;
  changeIconChecked()
  {
    // this.check_circle="fa fa-times-circle";
   return true;
  }
  changeIconRemoved()
  {
    // this.check_circle="fa fa-check-circle";
   return false;
  }
  removeLastElement()
  {
    console.log("chintuuuuu!!!!!!!!");
    this.addArray.splice(-1,1);
  }
  days:number;
  openTripDialog()
  {
    this.dialog.open(TripDialogComponent,{disableClose:true});
    // this.dialogRef.close({data:'data'});
    this.router.navigate(['plan-trip',this._mainService.getOption(),'trip-information'],{relativeTo:this.route});
    this._mainService.setLength(this.addArray.length);
    // console.log(this.addArray.length);
    if(this.est_hrs>10)
    {
     this.days=Math.round(this.est_hrs/10);
    }
    else
    {
      this.days=1;
    }
    this._mainService.setEstimatedDays(this.days);
  }
 
}
