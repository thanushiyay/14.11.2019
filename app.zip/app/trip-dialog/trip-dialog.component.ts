import { Component, OnInit } from '@angular/core';
import {ActivatedRoute,Router} from  '@angular/router';
import { MainServiceService } from '../main-service.service';
import { MainDialogComponent } from '../main-dialog/main-dialog.component';
import {MatDialog,MatDialogRef} from '@angular/material';
import { YoutubeDialogComponent } from '../youtube-dialog/youtube-dialog.component';
// import {NgbDate, NgbCalendar} from '@ng-bootstrap/ng-bootstrap';
import { DateRangePickerModule } from '@syncfusion/ej2-angular-calendars';
import {Title}  from '@angular/platform-browser';
import { SetTitleService } from '../set-title.service';
@Component({
  selector: 'app-trip-dialog',
  templateUrl: './trip-dialog.component.html',
  styleUrls: ['./trip-dialog.component.css']
})
export class TripDialogComponent implements OnInit {
  // _mainService: any;
  public start: Date;
  public end: Date;
  public startDate:any;
  no_of_people:number;
  constructor(private router:Router,private route:ActivatedRoute,
    private _mainService:MainServiceService,private dialog:MatDialog,
    private dialogRef:MatDialogRef<TripDialogComponent>,private _titleService:Title,
    private _setTitleService:SetTitleService)
    { 
    }
   title:string;
  ngOnInit() {
    // let require:any;
    // let dateFormat = require('dateformat');
    // let now = new Date();
    // this.start=dateFormat(now, "dd/mm/yyyy");
    // this.newMethod();
    this._setTitleService.checkPageTitle();
    this.no_of_people=0;
  }
  private newMethod() {
    this.no_of_people = 0;
  }

  dialogBack()
  {
     this.dialogRef.close();
    //  this.dialog.open(YoutubeDialogComponent,{disableClose:true,data:'data'});
     this.router.navigate(['plan-trip',this._mainService.getOption(),'where-to-go'],{relativeTo:this.route})
     setTimeout(()=>
     {
              this._setTitleService.checkPageTitle();
     },5);
    }
  dialogClose()
  {
    this.dialog.closeAll();
    this.dialog.afterAllClosed.subscribe(result=>
      {
         this.router.navigate(['../'],{relativeTo:this.route});
         setTimeout(()=>
         {
                  this._setTitleService.checkPageTitle();
         },5);
      });
     
      // this._setTitleService.checkPageTitle();
  }
  getArrayLength()
  {
      return this._mainService.getLength();
  }
  getOption()
  {
     return this._mainService.getOption();
  }
  getEstimated()
  {
     return this._mainService.getEstimatedDays();
  }
  getStartDate()
  {
       let sdate=<HTMLInputElement>document.getElementById('daterangepicker_input');
       console.log("sdate:"+sdate);
       console.log("hiiiiiiiiiiiiiiiiiii");
      //  let s=(<HTMLInputElement>sdate.split("-");
       
  }
  AddPeopleCount()
  {
     this.no_of_people=this.no_of_people+1;
  }
  deletePeopleCount()
  {
    if(this.no_of_people>0)
    {
     this.no_of_people=this.no_of_people-1;
    }
  }
}
